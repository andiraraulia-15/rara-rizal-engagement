# Undangan Pertunangan — Rara & Rizal

A mobile-first digital engagement invitation with RSVP, a live wishes wall,
a countdown, and one-tap Google Maps / Google Calendar links.

**Before you start:** I can't reach your GitHub or Google account from here —
I don't have network access or your login credentials, and this tool only
runs in a private sandbox. Everything below is fully built and tested for
logic and layout; the two steps marked ⚠️ are the ones only you can do,
since they require signing in to *your* Google and GitHub accounts.

---

## 1. What's in this folder

```
index.html                    ← the whole site (one page)
assets/css/style.css          ← all styling / design tokens
assets/js/config.js           ← ← EDIT THIS for names, date, venue, link
assets/js/main.js             ← site behaviour (countdown, RSVP, wishes...)
assets/img/                   ← bride.jpg, groom.jpg, couple.jpg (optimized)
assets/audio/music.mp3        ← background music (compressed for web)
google-apps-script/Code.gs    ← paste this into Google Apps Script
```

You will only ever need to touch **`assets/js/config.js`** for day-to-day
edits (names, date, venue, links). Everything else can be left alone.

---

## 2. ⚠️ Set up the Google Sheet + Apps Script (RSVP database)

This gives you a live spreadsheet of every RSVP, and powers the wishes wall.

1. Go to [sheets.google.com](https://sheets.google.com) and create a new,
   blank spreadsheet. Name it something like **"Engagement RSVP"**.
2. In the sheet, click **Extensions → Apps Script**.
3. Delete any starter code in the editor, then paste in the entire contents
   of `google-apps-script/Code.gs` from this project.
4. Click the **disk icon** (Save project), and give the project a name.
5. Click **Deploy → New deployment**.
6. Click the gear icon next to "Select type" and choose **Web app**.
7. Fill in:
   - Description: `Engagement RSVP backend` (anything you like)
   - Execute as: **Me** (your Google account)
   - Who has access: **Anyone**
8. Click **Deploy**. The first time, Google will ask you to authorize the
   script — click **Authorize access**, choose your Google account, and if
   you see an "unverified app" warning, click **Advanced → Go to (project
   name), unsafe** (this is expected for a script you wrote yourself).
9. Copy the **Web app URL** shown after deployment (it looks like
   `https://script.google.com/macros/s/XXXXXXXXXXXX/exec`).
10. Open `assets/js/config.js` in this project and paste that URL as the
    value of `appsScriptUrl`:
    ```js
    appsScriptUrl: "https://script.google.com/macros/s/XXXXXXXXXXXX/exec",
    ```
11. Save the file.

**Re-deploying later:** if you ever edit `Code.gs` again, you must create a
**new deployment version** (Deploy → Manage deployments → edit (pencil) →
Version: New version → Deploy) or your changes won't go live — Apps Script
web apps keep serving the version they were deployed with.

The sheet will automatically get a tab named **"RSVP"** with columns:
`Timestamp | Name | Attendance | Guests | Message`, created the first time
someone submits the form (or the first time you open the script URL).

> **Preview without a backend:** if you leave `appsScriptUrl` as the
> placeholder text, the site runs in "offline demo mode" — the form still
> works and wishes still appear, but everything is stored only in your own
> browser (`localStorage`), not shared with other guests or saved anywhere
> permanent. Good for previewing the design before you finish step 2.

---

## 3. ⚠️ Publish the site with GitHub Pages

1. Go to [github.com/new](https://github.com/new) and create a new
   repository (e.g. `rara-rizal-engagement`). It can be public or private —
   GitHub Pages works with both on a paid plan, but a **public** repo is
   free and simplest for this.
2. Upload every file and folder from this project into the root of that
   repository (drag-and-drop on the GitHub website works fine, or use `git`
   from your computer — see below).
3. In the repository, go to **Settings → Pages**.
4. Under "Build and deployment", set **Source** to **Deploy from a branch**,
   branch **main**, folder **/ (root)**. Click **Save**.
5. Wait 1–2 minutes, then refresh the page — GitHub will show your live URL,
   typically:
   ```
   https://<your-username>.github.io/<repository-name>/
   ```

### If you prefer the command line
```bash
cd path/to/this/project
git init
git add .
git commit -m "Engagement invitation site"
git branch -M main
git remote add origin https://github.com/<your-username>/<repository-name>.git
git push -u origin main
```
Then do step 3–5 above in the repository's Settings.

---

## 4. Customizing the invitation

Open **`assets/js/config.js`** — every editable value lives there with a
comment explaining it:

| Field | What it controls |
|---|---|
| `groomName` / `brideName` | Full names shown throughout the site |
| `groomShortName` / `brideShortName` | Short names on the opening "Buka Undangan" screen |
| `eventDateISO` | The exact date/time used by the countdown & calendar link (format: `YYYY-MM-DDTHH:MM:SS`) |
| `eventDateDisplay` / `eventTimeDisplay` | The human-readable text shown on the page |
| `venueName` / `venueAddress` / `venueMapsQuery` | Venue text and what's searched on Google Maps |
| `calendarTitle` / `calendarDescription` | What appears when a guest adds the event to Google Calendar |
| `appsScriptUrl` | Your Web app URL from step 2 |
| `closingQuote` / `closingSignature` | The closing section's text |

**To change photos:** replace the files in `assets/img/` with new ones
using the *same filenames* (`bride.jpg`, `groom.jpg`, `couple.jpg`), or
change the paths in the `images` block of `config.js`. Keep new photos
under ~1200px wide and export at ~80% JPEG quality so the site stays fast.

**To change the music:** replace `assets/audio/music.mp3` with a new file
of the same name, or update `musicSrc` in `config.js`. Keep it under a few
MB (re-encode at 96–128kbps if needed) so it loads quickly on mobile data.

After changing any file, commit and push to GitHub (or re-upload it on the
GitHub website) — GitHub Pages redeploys automatically within a minute or
two of every push to `main`.

---

## 5. Managing RSVPs

Every submission is a new row in the **"RSVP"** tab of your Google Sheet, so
you can sort, filter, or export it (File → Download → CSV/Excel) at any
time — no extra setup needed. The wishes wall on the site automatically
shows any RSVP that included a message, newest first, and refreshes every
20 seconds while the page is open.

---

## 6. Requirements checklist

- [x] RSVP form (name, attendance, guest count, message) syncing to Google Sheets, one row per submission
- [x] Wishes wall showing name + message, auto-refreshing
- [x] Countdown timer (days / hours / minutes / seconds)
- [x] Clickable venue address opening Google Maps
- [x] Clickable date/time opening Google Calendar pre-filled with title, date, time, venue, description
- [x] Opening cover, bride & groom, countdown, event details, map, RSVP, wishes, and closing sections
- [x] Floating music button with the provided audio
- [x] Fade-in scroll animations
- [x] Mobile-first, responsive layout tested for narrow (iPhone/Android) viewports
- [x] All couple/date/venue details centralized in one config file
- [ ] ⚠️ Google Apps Script deployed under **your** Google account (step 2 — needs your login)
- [ ] ⚠️ Site pushed to **your** GitHub repository and Pages enabled (step 3 — needs your login)

The two unchecked items are the ones that need your own account access —
everything else is complete and ready to go live the moment those two are
done.

---

## 7. Troubleshooting

- **Wishes/RSVP not saving:** double-check `appsScriptUrl` in `config.js`
  has no leading/trailing spaces, and that the Apps Script deployment's
  "Who has access" is set to **Anyone** (not "Anyone with a Google
  account", which will block guests who aren't signed in).
- **Countdown looks wrong:** `eventDateISO` has no timezone suffix, so it's
  interpreted in the *guest's own browser timezone*. If your guests are all
  in one timezone (e.g. WITA/Makassar), that's usually fine; for a fully
  timezone-correct countdown for guests abroad, add an offset, e.g.
  `2026-10-10T10:00:00+08:00`.
- **Map shows the wrong place:** make `venueMapsQuery` more specific, or
  replace it with exact coordinates like `-5.1477,119.4995`.
